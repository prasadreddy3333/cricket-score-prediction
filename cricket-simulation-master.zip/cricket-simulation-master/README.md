Cricket-Simulation
==================
This is our 3rd Sem C++ Project. It simulates a cricket match between two teams.

Instructions on how to use:-

1. Download the Project.

2. Save it in your Desktop (Ubuntu)

3. And copy the following code and save it as a ".sh" file in the "home" dir.

  "#!/bin/bash
  
  cd Desktop/Cricket-Simulation/
  
  g++ project.cpp
  
  ./a.out
  
  gnuplot plot.cmd -p "

4. Exectute the ".sh" file through Terminal.

5. And Play the game.

NOTE:- This game also works in Windows, but the GNU-Plot Feature is not available there.
